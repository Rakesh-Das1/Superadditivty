# Superadditvity_2026

Lovász theta and independence number calculations for Kochen–Specker-type graphs.
Each folder holds two notebooks: `Lovasz_Theta.ipynb` and `Independence_Number.ipynb`.

| Folder | Graph info |
|---|---|
| [Cabello_18](Cabello_18/) | ***Cabello* 18** $\theta(G)$=4.5 $\alpha$=4 d=4 |
| [Conway_Kochen_31](Conway_Kochen_31/) | $Conway-Kochen-31$ |
| [Peres_24](Peres_24/) | Peres 24: $\theta(G)$=6 $\alpha$=5 d=4 |
| [YO_25](YO_25/) | YO-25 $\theta(G)$=13 $\alpha$=13 d=3 |
| [Lisonek_21](Lisonek_21/) | $Lisoněk$ $\theta(G)$=3.5 $\alpha$=3 d=6 |
| [Conway_Kochen_55](Conway_Kochen_55/) | $COMPLETED$ 55- $CONWAY-KOCHEN SET$: $\theta$=25 $\alpha$=25 d=3 |
| [Extended_Clifton_13](Extended_Clifton_13/) | $EXTENDED$ $CLIFTON$: $\alpha$=5 $\theta$=5 d=3 |
| [Kernaghan_20](Kernaghan_20/) | $Kernaghan$ -20, d=4, $\theta$=5.5, $\alpha$=5 |
| [Kernaghan_Peres_36](Kernaghan_Peres_36/) | $Kernaghan Peres$-36, d=8, $\theta$-5.59, $\alpha$=5 |
| [SIC_k9](SIC_k9/) | $SIC$ k=9, d=3, $\theta$-37.8, $\alpha$=36 |
| [Yu_Oh_13](Yu_Oh_13/) | *Yu-Oh 13 d=3 $\theta=5$  $\alpha=5$* |
| [Clifton_8](Clifton_8/) | $Clifton$ $\alpha=3, \theta=3.38$ |
